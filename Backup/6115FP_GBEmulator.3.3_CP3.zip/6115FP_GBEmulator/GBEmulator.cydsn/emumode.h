/*
This file contains precompiler definitions that change the function of the emulator 
*/
#ifndef EMU_MODE_H
#define EMU_MODE_H
#define DEBUG_MODE true
#define DEBUG_BREAKPOINT_ON true
#define DEBUG_BREAKPOINT 0x0200
#define DEBUG_MEMORY_DISPLAY_LOC 0xC000
    
#define TETRIS 0
#define TEST_ROM_CPU_INSTRS_1 1
#define TEST_ROM_CPU_INSTRS_6 6

// ROM selection
#define ROM TEST_ROM_CPU_INSTRS_6
    
#define START_IN_BIOS true
#endif